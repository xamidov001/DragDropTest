package uz.pdp.dragdroptest

data class Item(
    var name:String="",
    var visibility:Boolean=false
)